clear all;
close all;

% We define the data providen in the statemen
fc=1e3;             % Pole freq
Fs=1e6;             % Sampling freq
R1=1e3;             
Rf=10e3;            
Cf=1/(2*pi*Rf*fc)
f=0:10:1e6;         % Array of frequenciess       
w=2*pi.*f;          % Array of anguar frequencies

% In S Domain
num=-Rf/R1;
den=[(Rf*Cf) 1];

% We calculate the value of Ceq1 and Ceq2
Ceq2=1/(Rf*Fs)       % We get the formula from the equivalency of a resistor in SC
Ceq1=1/(R1*Fs)

% In S domain
num1=-(Ceq1/Ceq2)/(1-Ceq1/Ceq2);
den1=[1 -1/(1+Ceq1/Ceq2)];

% We use both fucntion to get H and W
[h,w_plot]=freqs(num,den,w);

[h1,w_plot1]=freqz(num1,den1,w);

% We plot the results
semilogx(w_plot/(2*pi),20*log10(abs(h)));
grid;
hold on
semilogx(w_plot1/(2*pi),20*log10(abs(h1)), '--r');

